<?php
// Heading 
$_['heading_title']  = 'Category on Home';

?>