<?php
// Heading 
$_['heading_title']  = 'Категория на главной';
?>