<?php
// Heading 
$_['heading_title'] = 'Популярные товары';

// Text
$_['text_reviews']  = 'На основании %s отзывов.'; 
?>